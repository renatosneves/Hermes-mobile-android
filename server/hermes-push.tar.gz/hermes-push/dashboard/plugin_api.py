"""hermes-push dashboard routes, mounted at /api/plugins/hermes-push/ (behind dashboard auth)."""

import logging
import sys
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

_PLUGIN_DIR = str(Path(__file__).resolve().parent.parent)
if _PLUGIN_DIR not in sys.path:  # loaded by file path, so the sibling module needs sys.path
    sys.path.insert(0, _PLUGIN_DIR)
import push_core as core  # noqa: E402

log = logging.getLogger("hermes_push")
router = APIRouter()


class RegisterBody(BaseModel):
    device_id: str
    endpoint: str
    p256dh: str
    auth: str
    prefs: Optional[dict] = None


class DeviceBody(BaseModel):
    device_id: str


def _store() -> "core.Store":
    return core.Store()


@router.post("/register")
def register(body: RegisterBody):
    if not body.device_id or len(body.device_id) > 128:
        raise HTTPException(400, "invalid device_id")
    err = core.validate_subscription(body.endpoint, body.p256dh, body.auth)
    if err:
        raise HTTPException(400, err)
    _store().upsert(body.device_id, {
        "endpoint": body.endpoint, "p256dh": body.p256dh, "auth": body.auth,
        "prefs": core.sanitize_prefs(body.prefs),
    })
    log.info("hermes-push: registered device %s -> %s", core.redact(body.device_id), core.redact(body.endpoint))
    return {"ok": True}


@router.post("/unregister")
def unregister(body: DeviceBody):
    _store().remove(body.device_id)
    return {"ok": True}


@router.post("/test")
def test(body: DeviceBody):
    store = _store()
    rec = store.devices().get(body.device_id)
    if not rec:
        raise HTTPException(404, "unknown device")
    payload = {
        "v": 1, "id": f"test-{core.secrets.token_hex(8)}", "type": "test", "profile": core.profile_name(),
        "session_id": None, "title": "Hermes push test", "body": "Notifications are working.",
        "approval_id": None, "ts": int(core.time.time() * 1000),
    }
    status = core.Sender(store).send_one(body.device_id, rec, payload)
    if status is None:
        raise HTTPException(502, "push send failed")
    return {"ok": 200 <= status < 300, "status": status}


@router.get("/status")
def status():
    data = _store().load()
    st = data.get("state", {})
    return {"ok": True, "devices": len(data["devices"]),
            "hooks_active": bool(st.get("hooks_registered_at")),
            "last_push_at": st.get("last_push_at")}
