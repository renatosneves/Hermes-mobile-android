"""hermes-push shared core: storage, RFC8291 encryption, sender and event dispatch.

Stdlib + ``cryptography`` only. Used by the agent/gateway hooks (``__init__.py``) and by the
dashboard routes (``dashboard/plugin_api.py``); the two may run in different processes, so all
shared state lives in files under the push dir.
"""
from __future__ import annotations

import base64
import contextlib
import fcntl
import hashlib
import json
import logging
import os
import queue
import re
import secrets
import struct
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

log = logging.getLogger("hermes_push")

TYPES = ("approval", "task", "message", "scheduled")
BOT_MODES = ("all", "important", "off")
TTL = {"approval": 86400, "task": 21600, "message": 21600, "scheduled": 21600, "test": 21600}
URGENCY = {"approval": "high", "task": "normal", "message": "normal", "scheduled": "low", "test": "normal"}
TITLE_MAX, BODY_MAX, PAYLOAD_MAX = 80, 240, 3000
HTTP_TIMEOUT = 10
COLLAPSE_WINDOW = 20.0
QUEUE_MAX = 64
DEDUPE_MAX = 2048
RECORD_SIZE = 4096


# ---------------------------------------------------------------- helpers
def b64u_decode(s: str) -> bytes:
    s = s.strip()
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def b64u_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def redact(value: Any) -> str:
    """Log-safe form of an endpoint/key: never the full value."""
    s = str(value or "")
    m = re.match(r"^(https?://[^/]+)", s)
    if m:
        return f"{m.group(1)}/…{s[-4:]}" if len(s) > len(m.group(1)) + 4 else m.group(1)
    return f"…{s[-4:]}" if len(s) > 4 else "…"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def make_topic(type_: str, profile: str, session_id: Optional[str]) -> str:
    """<=32 url-safe chars, stable per type+profile+session."""
    h = hashlib.sha256(f"{type_}:{profile}:{session_id or ''}".encode()).digest()
    return b64u_encode(h)[:22]


# ---------------------------------------------------------------- profile / paths
def profile_name() -> str:
    home = os.environ.get("HERMES_HOME")
    if not home:
        return "default"
    p = Path(home)
    return p.name if p.parent.name == "profiles" and p.name else "default"


def root_home() -> Path:
    home = os.environ.get("HERMES_HOME")
    if not home:
        return Path.home() / ".hermes"
    p = Path(home)
    if p.parent.name == "profiles":
        return p.parent.parent
    return p


def push_dir() -> Path:
    override = os.environ.get("HERMES_PUSH_DIR")
    return Path(override) if override else root_home() / "push"


# ---------------------------------------------------------------- storage
class Store:
    """Shared JSON store: {"devices": {id: {...}}, "state": {...}}. flock + atomic replace, mode 0600."""

    def __init__(self, directory: Optional[Path] = None):
        self.dir = Path(directory) if directory else push_dir()
        self.path = self.dir / "subscriptions.json"
        self._lockpath = self.dir / "subscriptions.lock"

    @contextlib.contextmanager
    def _locked(self):
        self.dir.mkdir(parents=True, exist_ok=True)
        with contextlib.suppress(OSError):
            os.chmod(self.dir, 0o700)
        fd = os.open(self._lockpath, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            with contextlib.suppress(OSError):
                fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)

    def _read(self) -> dict:
        try:
            data = json.loads(self.path.read_text("utf-8"))
            if isinstance(data, dict):
                data.setdefault("devices", {})
                data.setdefault("state", {})
                return data
        except FileNotFoundError:
            pass
        except (OSError, ValueError):
            log.warning("hermes-push: unreadable subscriptions file, treating as empty")
        return {"devices": {}, "state": {}}

    def _write(self, data: dict) -> None:
        tmp = self.dir / f".subscriptions.{os.getpid()}.{secrets.token_hex(4)}.tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
            os.chmod(self.path, 0o600)
        except BaseException:
            with contextlib.suppress(OSError):
                os.unlink(tmp)
            raise

    def load(self) -> dict:
        with self._locked():
            return self._read()

    def devices(self) -> Dict[str, dict]:
        return self.load()["devices"]

    def upsert(self, device_id: str, record: dict) -> None:
        with self._locked():
            data = self._read()
            old = data["devices"].get(device_id, {})
            record = {**record, "created_at": old.get("created_at") or now_iso(), "updated_at": now_iso()}
            data["devices"][device_id] = record
            self._write(data)

    def remove(self, device_id: str) -> bool:
        with self._locked():
            data = self._read()
            if data["devices"].pop(device_id, None) is None:
                return False
            self._write(data)
            return True

    def set_state(self, **kv: Any) -> None:
        with self._locked():
            data = self._read()
            data["state"].update(kv)
            self._write(data)


# ---------------------------------------------------------------- validation / prefs
def default_prefs() -> dict:
    return {"types": {t: True for t in TYPES}, "bots": {}}


def sanitize_prefs(prefs: Any) -> dict:
    out = default_prefs()
    if not isinstance(prefs, dict):
        return out
    types = prefs.get("types")
    if isinstance(types, dict):
        for t in TYPES:
            if t in types:
                out["types"][t] = bool(types[t])
    bots = prefs.get("bots")
    if isinstance(bots, dict):
        for k, v in list(bots.items())[:200]:
            if isinstance(k, str) and 0 < len(k) <= 64 and v in BOT_MODES:
                out["bots"][k] = v
    return out


def validate_subscription(endpoint: Any, p256dh: Any, auth: Any) -> Optional[str]:
    """Return an error string, or None when valid."""
    if not isinstance(endpoint, str) or not re.match(r"^https?://[^\s/]+", endpoint) or len(endpoint) > 2048:
        return "invalid endpoint"
    try:
        pub = b64u_decode(p256dh)
        if len(pub) != 65 or pub[0] != 4:
            return "invalid p256dh"
        ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), pub)
    except Exception:
        return "invalid p256dh"
    try:
        if len(b64u_decode(auth)) != 16:
            return "invalid auth"
    except Exception:
        return "invalid auth"
    return None


def wants(prefs: dict, type_: str, profile: str, important: bool) -> bool:
    """Prefs filter. ``test`` always passes; ``important`` = approvals + blocked/failed tasks."""
    if type_ == "test":
        return True
    if not (prefs.get("types") or {}).get(type_, True):
        return False
    mode = (prefs.get("bots") or {}).get(profile, "all")
    if mode == "off":
        return False
    if mode == "important":
        return important or type_ == "approval"
    return True


# ---------------------------------------------------------------- text
_MD_RULES = [
    (re.compile(r"```[^\n]*\n?(.*?)```", re.S), r"\1"),
    (re.compile(r"!\[([^\]]*)\]\([^)]*\)"), r"\1"),
    (re.compile(r"\[([^\]]+)\]\([^)]*\)"), r"\1"),
    (re.compile(r"^\s{0,3}#{1,6}\s*", re.M), ""),
    (re.compile(r"^\s*>\s?", re.M), ""),
    (re.compile(r"^\s*[-*+]\s+", re.M), ""),
    (re.compile(r"(\*\*|__)(.+?)\1", re.S), r"\2"),
    (re.compile(r"(?<![\w*])[*_](?!\s)(.+?)(?<!\s)[*_](?![\w*])", re.S), r"\1"),
    (re.compile(r"`([^`]*)`"), r"\1"),
]


def clean_text(text: Any, limit: int) -> str:
    s = str(text or "")
    for rx, rep in _MD_RULES:
        s = rx.sub(rep, s)
    s = re.sub(r"\s+", " ", s).strip()
    if len(s) > limit:
        s = s[: limit - 1].rstrip() + "…"
    return s


# ---------------------------------------------------------------- RFC 8291 aes128gcm
def _hkdf(salt: bytes, ikm: bytes, info: bytes, length: int) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=salt, info=info).derive(ikm)


def encrypt(plaintext: bytes, p256dh: str, auth: str, *, salt: Optional[bytes] = None,
            as_private: Optional[ec.EllipticCurvePrivateKey] = None) -> bytes:
    """Encrypt for a Web Push receiver (single record, RFC 8188 header + RFC 8291 keys)."""
    ua_pub = b64u_decode(p256dh)
    auth_secret = b64u_decode(auth)
    salt = salt or os.urandom(16)
    as_private = as_private or ec.generate_private_key(ec.SECP256R1())
    as_pub = as_private.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    ua_key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), ua_pub)
    ecdh = as_private.exchange(ec.ECDH(), ua_key)
    prk = _hkdf(auth_secret, ecdh, b"WebPush: info\x00" + ua_pub + as_pub, 32)
    cek = _hkdf(salt, prk, b"Content-Encoding: aes128gcm\x00", 16)
    nonce = _hkdf(salt, prk, b"Content-Encoding: nonce\x00", 12)
    if len(plaintext) + 1 + 16 > RECORD_SIZE - 86:
        raise ValueError("payload too large for a single record")
    ct = AESGCM(cek).encrypt(nonce, plaintext + b"\x02", None)
    return salt + struct.pack(">IB", RECORD_SIZE, len(as_pub)) + as_pub + ct


def decrypt(body: bytes, receiver_private: ec.EllipticCurvePrivateKey, auth: str) -> bytes:
    """Receiver side (used by tests; mirrors what the phone does)."""
    salt, rs, idlen = body[:16], struct.unpack(">I", body[16:20])[0], body[20]
    as_pub = body[21:21 + idlen]
    ct = body[21 + idlen:]
    ua_pub = receiver_private.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    ecdh = receiver_private.exchange(
        ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), as_pub))
    prk = _hkdf(b64u_decode(auth), ecdh, b"WebPush: info\x00" + ua_pub + as_pub, 32)
    cek = _hkdf(salt, prk, b"Content-Encoding: aes128gcm\x00", 16)
    nonce = _hkdf(salt, prk, b"Content-Encoding: nonce\x00", 12)
    pt = AESGCM(cek).decrypt(nonce, ct, None)
    stripped = pt.rstrip(b"\x00")
    return stripped[:-1] if stripped.endswith(b"\x02") else pt


# ---------------------------------------------------------------- HTTP
def http_post(url: str, body: bytes, headers: Dict[str, str], timeout: float = HTTP_TIMEOUT) -> int:
    """POST and return the HTTP status (HTTP errors are returned, not raised). Replaced in tests."""
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - http(s) validated at register
            return resp.status
    except urllib.error.HTTPError as e:
        return e.code


class Sender:
    """Builds, encrypts and POSTs pushes to subscriptions; drops dead ones."""

    def __init__(self, store: Optional[Store] = None, post: Optional[Callable[..., int]] = None):
        self.store = store or Store()
        self._post = post  # None -> module-level http_post (looked up at call time)

    def send_one(self, device_id: str, rec: dict, payload: dict) -> Optional[int]:
        """Send to one device. Returns HTTP status, or None on local failure."""
        type_ = payload.get("type", "message")
        try:
            body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
            if len(body) > PAYLOAD_MAX:
                payload = {**payload, "body": clean_text(payload.get("body"), 120)}
                body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
            data = encrypt(body, rec["p256dh"], rec["auth"])
            headers = {
                "Content-Encoding": "aes128gcm",
                "Content-Type": "application/octet-stream",
                "TTL": str(TTL.get(type_, 21600)),
                "Urgency": URGENCY.get(type_, "normal"),
                "Topic": make_topic(type_, payload.get("profile", ""), payload.get("session_id")),
            }
            status = (self._post or http_post)(rec["endpoint"], data, headers, HTTP_TIMEOUT)
        except Exception as e:
            log.warning("hermes-push: send to %s failed: %s", redact(rec.get("endpoint")), type(e).__name__)
            return None
        if status in (404, 410):
            log.info("hermes-push: subscription %s gone (%s), removing", redact(device_id), status)
            with contextlib.suppress(Exception):
                self.store.remove(device_id)
        elif 200 <= status < 300:
            with contextlib.suppress(Exception):
                self.store.set_state(last_push_at=now_iso())
        else:
            log.warning("hermes-push: push service %s returned %s", redact(rec.get("endpoint")), status)
        return status

    def send_event(self, payload: dict, important: bool) -> int:
        """Fan out to every device whose prefs accept the event. Returns number attempted."""
        n = 0
        for did, rec in list(self.store.devices().items()):
            if wants(rec.get("prefs") or default_prefs(), payload["type"], payload["profile"], important):
                self.send_one(did, rec, payload)
                n += 1
        return n


# ---------------------------------------------------------------- dispatcher
class Notifier:
    """Non-blocking front door: ``notify()`` returns immediately; a daemon worker sends."""

    def __init__(self, sender: Optional[Sender] = None, *, now: Callable[[], float] = time.monotonic,
                 schedule: Optional[Callable[[float, Callable[[], None]], Any]] = None):
        self.sender = sender or Sender()
        self._now = now
        self._schedule = schedule or self._timer
        self._q: "queue.Queue[tuple]" = queue.Queue(maxsize=QUEUE_MAX)
        self._worker: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._seen: Dict[str, None] = {}
        self._last_msg: Dict[tuple, float] = {}
        self._pending: Dict[tuple, tuple] = {}

    @staticmethod
    def _timer(delay: float, fn: Callable[[], None]) -> None:
        t = threading.Timer(delay, fn)
        t.daemon = True
        t.start()

    def _ensure_worker(self) -> None:
        if self._worker is None or not self._worker.is_alive():
            self._worker = threading.Thread(target=self._run, name="hermes-push", daemon=True)
            self._worker.start()

    def _run(self) -> None:
        while True:
            payload, important = self._q.get()
            try:
                self.sender.send_event(payload, important)
            except Exception:
                log.warning("hermes-push: dispatch failed", exc_info=True)
            finally:
                self._q.task_done()

    def _enqueue(self, payload: dict, important: bool) -> None:
        with self._lock:
            self._ensure_worker()
        try:
            self._q.put_nowait((payload, important))
        except queue.Full:
            log.warning("hermes-push: queue full, dropping %s push", payload.get("type"))

    def _first_time(self, id_: str) -> bool:
        with self._lock:
            if id_ in self._seen:
                return False
            self._seen[id_] = None
            while len(self._seen) > DEDUPE_MAX:
                self._seen.pop(next(iter(self._seen)))
            return True

    def notify(self, type_: str, *, profile: str, title: str, body: str, session_id: Optional[str] = None,
               approval_id: Optional[str] = None, important: bool = False, id: Optional[str] = None) -> bool:
        """Queue one push. Never raises. Returns False when dropped (dup / empty / collapsed-for-later)."""
        try:
            payload = {
                "v": 1, "id": id or secrets.token_hex(12), "type": type_, "profile": profile,
                "session_id": session_id, "title": clean_text(title, TITLE_MAX) or profile,
                "body": clean_text(body, BODY_MAX), "approval_id": approval_id,
                "ts": int(time.time() * 1000),
            }
            if not self._first_time(payload["id"]):
                return False
            if type_ == "message":
                return self._collapse(payload, important)
            self._enqueue(payload, important)
            return True
        except Exception:
            log.warning("hermes-push: notify failed", exc_info=True)
            return False

    def _collapse(self, payload: dict, important: bool) -> bool:
        """At most one message push per profile+session per window; the latest text is flushed at its end."""
        key = (payload["profile"], payload["session_id"])
        with self._lock:
            now = self._now()
            last = self._last_msg.get(key)
            if last is None or now - last >= COLLAPSE_WINDOW:
                self._last_msg[key] = now
                if len(self._last_msg) > 512:
                    for k in [k for k, v in self._last_msg.items() if now - v > COLLAPSE_WINDOW][:256]:
                        self._last_msg.pop(k, None)
                send_now = True
            else:
                send_now = False
                first_pending = key not in self._pending
                self._pending[key] = (payload, important)
        if send_now:
            self._enqueue(payload, important)
            return True
        if first_pending:
            self._schedule(max(0.0, COLLAPSE_WINDOW - (now - last)), lambda: self._flush(key))
        return False

    def _flush(self, key: tuple) -> None:
        with self._lock:
            item = self._pending.pop(key, None)
            if item:
                self._last_msg[key] = self._now()
        if item:
            self._enqueue(*item)

    def drain(self, timeout: float = 5.0) -> None:
        """Wait for queued sends (tests)."""
        end = time.time() + timeout
        while self._q.unfinished_tasks and time.time() < end:
            time.sleep(0.01)


_notifier: Optional[Notifier] = None
_notifier_lock = threading.Lock()


def get_notifier() -> Notifier:
    global _notifier
    with _notifier_lock:
        if _notifier is None:
            _notifier = Notifier()
        return _notifier
