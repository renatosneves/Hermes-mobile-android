"""hermes-push: send Web Push notifications to the phone app.

Hooks (all observers; never raise into the agent):
  pre_approval_request   -> "approval"
  kanban_task_completed  -> "task"
  kanban_task_blocked    -> "task" (important)
  post_llm_call          -> "message" (or "scheduled" when platform == "cron"); fires once per turn
"""
from __future__ import annotations

import hashlib
import logging
import time
from typing import Any

try:  # loaded as a package by Hermes
    from . import push_core as core
except ImportError:  # pragma: no cover - flat import (tests)
    import push_core as core

log = logging.getLogger("hermes_push")


def _profile() -> str:
    return core.profile_name()


def _pending_request_id(session_key: str, command: Any) -> str:
    """Newest pending gateway approval id for this session, preferring one whose command matches."""
    if not session_key:
        return ""
    try:
        from tools.approval import list_gateway_approvals
        pending = list_gateway_approvals(session_key)
    except Exception:
        return ""
    for entry in reversed(pending):
        if str(entry.get("command") or "") == str(command or "") and entry.get("request_id"):
            return str(entry["request_id"])
    return str(pending[-1].get("request_id") or "") if pending else ""


def on_pre_approval_request(command: Any = "", description: Any = "", pattern_key: Any = "",
                            session_key: Any = None, surface: Any = "", coalesced: bool = False,
                            session_id: Any = None, **_: Any) -> None:
    try:
        if coalesced:  # follower of an already-announced identical approval
            return
        sk = str(session_key or "")
        # The gateway queues the entry before firing this hook, so its real request_id
        # (what approval.respond expects) is already listed; fall back to a stable hash.
        aid = _pending_request_id(sk, command) or hashlib.sha1(
            f"{sk}|{command}|{pattern_key}".encode()).hexdigest()[:16]
        core.get_notifier().notify(
            "approval", profile=_profile(), session_id=str(session_id or sk) or None,
            approval_id=aid, important=True,
            id=f"approval-{aid}-{int(time.time() * 1000)}",
            title=f"{_profile()}: approval needed",
            body=str(description or command or "A command needs approval"),
        )
    except Exception:
        log.debug("hermes-push approval hook failed", exc_info=True)


def _task(event: str, task_id: Any, summary: Any, important: bool, verb: str, profile_name: Any) -> None:
    try:
        prof = str(profile_name or _profile())
        core.get_notifier().notify(
            "task", profile=prof, session_id=str(task_id), important=important,
            id=f"task-{event}-{task_id}",
            title=f"{prof}: task {verb}", body=f"{task_id}: {summary or ''}".rstrip(": "),
        )
    except Exception:
        log.debug("hermes-push task hook failed", exc_info=True)


def on_kanban_task_completed(task_id: Any = "", summary: Any = "", profile_name: Any = None, **_: Any) -> None:
    _task("completed", task_id, summary, False, "done", profile_name)


def on_kanban_task_blocked(task_id: Any = "", reason: Any = "", profile_name: Any = None, **_: Any) -> None:
    _task("blocked", task_id, reason, True, "blocked", profile_name)


def on_post_llm_call(session_id: Any = None, turn_id: Any = None, assistant_response: Any = None,
                     platform: Any = None, **_: Any) -> None:
    try:
        text = assistant_response if isinstance(assistant_response, str) else ""
        if not text.strip():
            return
        cron = str(platform or "").lower() == "cron"
        prof = _profile()
        sid = str(session_id) if session_id else None
        core.get_notifier().notify(
            "scheduled" if cron else "message", profile=prof, session_id=sid,
            id=f"{'sched' if cron else 'msg'}-{sid}-{turn_id or time.time_ns()}",
            title=f"{prof}: scheduled run" if cron else prof, body=text,
        )
    except Exception:
        log.debug("hermes-push message hook failed", exc_info=True)


def register(ctx) -> None:
    ctx.register_hook("pre_approval_request", on_pre_approval_request)
    ctx.register_hook("kanban_task_completed", on_kanban_task_completed)
    ctx.register_hook("kanban_task_blocked", on_kanban_task_blocked)
    ctx.register_hook("post_llm_call", on_post_llm_call)
    try:
        core.Store().set_state(hooks_registered_at=core.now_iso())
    except Exception:
        log.debug("hermes-push: could not record hook registration", exc_info=True)
