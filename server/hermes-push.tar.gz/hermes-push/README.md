# hermes-push

Sends Web Push (RFC 8030, encrypted per RFC 8291 `aes128gcm`, no VAPID) to a phone via
UnifiedPush (ntfy distributor). Implements contract v1.

## Install
Copy this directory to `~/.hermes/plugins/hermes-push/` (each profile that should push, or the
shared plugin dir) and enable it (`hermes plugins enable hermes-push`). The dashboard (default
profile) mounts `dashboard/plugin_api.py` at `/api/plugins/hermes-push/` behind normal dashboard auth.
Requires only `cryptography` (already a Hermes dependency); `fastapi` is the dashboard's.

## Routes
`POST /register`, `POST /unregister`, `POST /test`, `GET /status` (see contract).

## Storage
One file shared by all profiles: `<root>/push/subscriptions.json` (root = `HERMES_HOME` with
`/profiles/<x>` stripped, else `~/.hermes`; override dir with `HERMES_PUSH_DIR`). Written
atomically (tmp + `os.replace`) under an `fcntl` lock, mode 0600 (dir 0700). It also holds
`state.last_push_at` and `state.hooks_registered_at` inside the same file (used by `/status`). Endpoints and keys are
never logged in full.

## Events
| Hook | Push |
|---|---|
| `pre_approval_request` (skips `coalesced=True`) | `approval`, urgency high, TTL 24 h |
| `kanban_task_completed` / `kanban_task_blocked` | `task` (blocked counts as important) |
| `post_llm_call` (once per user-visible turn, after the tool loop) | `message`; `scheduled` when `platform == "cron"` |

Prefs: per-type switches; per-bot `all` / `important` (approvals + blocked tasks) / `off`.
Sending is off the agent thread (bounded queue of 64, one daemon worker, 10 s timeouts, all
exceptions logged and swallowed). HTTP 404/410 removes the subscription. The same `id` is never
sent twice; message bursts per profile+session are limited to one push per 20 s, with the latest
text flushed at the window end (and replacing older ones through the `Topic` header).
No heartbeats, no polling.

## Tests
`python3 -m pytest` in this directory (needs `pytest`, `cryptography`; `fastapi` for route tests).
