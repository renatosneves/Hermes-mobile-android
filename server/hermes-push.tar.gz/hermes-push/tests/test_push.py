import json
import os
import stat
from types import SimpleNamespace

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

import push_core as core


def make_receiver():
    priv = ec.generate_private_key(ec.SECP256R1())
    pub = priv.public_key().public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
    auth = core.b64u_encode(os.urandom(16))
    return priv, core.b64u_encode(pub), auth


class FakePost:
    def __init__(self, status=201):
        self.status, self.calls = status, []

    def __call__(self, url, body, headers, timeout=10):
        self.calls.append((url, body, headers, timeout))
        return self.status


@pytest.fixture
def env(tmp_path, monkeypatch):
    monkeypatch.setenv("HERMES_PUSH_DIR", str(tmp_path / "push"))
    monkeypatch.setenv("HERMES_HOME", str(tmp_path / ".hermes" / "profiles" / "bot1"))
    store = core.Store()
    priv, p256dh, auth = make_receiver()
    store.upsert("dev1", {"endpoint": "https://push.example/abc123456", "p256dh": p256dh, "auth": auth,
                          "prefs": core.default_prefs()})
    return SimpleNamespace(store=store, priv=priv, p256dh=p256dh, auth=auth, tmp=tmp_path)


def notifier(env, post, clock=None, scheduled=None):
    sender = core.Sender(env.store, post)
    kw = {}
    if clock:
        kw["now"] = clock
    if scheduled is not None:
        kw["schedule"] = lambda d, fn: scheduled.append((d, fn))
    return core.Notifier(sender, **kw)


# ---- encryption
def test_encrypt_roundtrip():
    priv, p256dh, auth = make_receiver()
    msg = json.dumps({"hello": "wörld", "n": 1}).encode()
    body = core.encrypt(msg, p256dh, auth)
    assert core.decrypt(body, priv, auth) == msg
    assert body[16:20] == (4096).to_bytes(4, "big") and body[20] == 65


def test_encrypt_rfc8291_vector():
    # RFC 8291 appendix A test vector
    ua_pub = "BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4"
    auth = "BTBZMqHH6r4Tts7J_aSIgg"
    as_priv = ec.derive_private_key(
        int.from_bytes(core.b64u_decode("yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw"), "big"), ec.SECP256R1())
    salt = core.b64u_decode("DGv6ra1nlYgDCS1FRnbzlw")
    body = core.encrypt(b"When I grow up, I want to be a watermelon", ua_pub, auth, salt=salt, as_private=as_priv)
    expected = ("DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN")
    assert core.b64u_encode(body) == expected


# ---- text
def test_clean_text_markdown_and_truncate():
    t = core.clean_text("# Title\n**bold** and `code` [link](http://x.y)\n- item", 240)
    assert t == "Title bold and code link item"
    long = core.clean_text("a" * 500, 240)
    assert len(long) == 240 and long.endswith("…")


def test_topic_is_short_urlsafe_and_stable():
    t = core.make_topic("message", "bot1", "s1")
    assert len(t) <= 32 and t == core.make_topic("message", "bot1", "s1")
    assert t != core.make_topic("message", "bot1", "s2")
    assert all(c.isalnum() or c in "-_" for c in t)


# ---- storage
def test_store_roundtrip_mode_and_atomic(env):
    assert stat.S_IMODE(env.store.path.stat().st_mode) == 0o600
    assert "dev1" in env.store.devices()
    env.store.upsert("dev2", {"endpoint": "https://e/2", "p256dh": "x", "auth": "y", "prefs": {}})
    assert set(env.store.devices()) == {"dev1", "dev2"}
    assert env.store.remove("dev2") and not env.store.remove("dev2")
    assert not [p for p in env.store.dir.iterdir() if p.name.endswith(".tmp")]


def test_store_corrupt_file_is_empty(env):
    env.store.path.write_text("{not json")
    assert env.store.devices() == {}


def test_root_derivation(tmp_path, monkeypatch):
    monkeypatch.delenv("HERMES_PUSH_DIR", raising=False)
    monkeypatch.setenv("HERMES_HOME", str(tmp_path / ".hermes" / "profiles" / "x"))
    assert core.push_dir() == tmp_path / ".hermes" / "push" and core.profile_name() == "x"
    monkeypatch.setenv("HERMES_HOME", str(tmp_path / ".hermes"))
    assert core.push_dir() == tmp_path / ".hermes" / "push" and core.profile_name() == "default"
    monkeypatch.setenv("HERMES_PUSH_DIR", str(tmp_path / "o"))
    assert core.push_dir() == tmp_path / "o"


def test_validate_subscription():
    _, p, a = make_receiver()
    assert core.validate_subscription("https://x.y/z", p, a) is None
    assert core.validate_subscription("ftp://x", p, a)
    assert core.validate_subscription("https://x.y/z", "AAAA", a)
    assert core.validate_subscription("https://x.y/z", p, "AAAA")


def test_redact_never_full():
    r = core.redact("https://ntfy.sh/up/SECRETTOKEN1234")
    assert "SECRETTOKEN" not in r and r.startswith("https://ntfy.sh")


# ---- prefs
def test_prefs_filtering():
    p = core.sanitize_prefs({"types": {"message": False}, "bots": {"a": "important", "b": "off", "c": "bogus"}})
    assert not core.wants(p, "message", "x", False)
    assert core.wants(p, "task", "x", False)
    assert not core.wants(p, "task", "b", True) and not core.wants(p, "approval", "b", True)
    assert core.wants(p, "approval", "a", True) and core.wants(p, "task", "a", True)
    assert not core.wants(p, "task", "a", False)
    assert core.wants(p, "task", "c", False)  # invalid dropped -> default all
    assert core.wants(p, "test", "b", False)


def test_event_respects_device_prefs(env):
    env.store.upsert("dev1", {**env.store.devices()["dev1"], "prefs": core.sanitize_prefs({"bots": {"bot1": "off"}})})
    post = FakePost()
    n = notifier(env, post)
    n.notify("approval", profile="bot1", title="t", body="b", important=True)
    n.drain()
    assert post.calls == []


# ---- sending
def test_send_headers_and_decrypts(env):
    post = FakePost()
    n = notifier(env, post)
    assert n.notify("approval", profile="bot1", session_id="s1", title="T", body="**run** it",
                    approval_id="ap1", important=True, id="i1")
    n.drain()
    url, body, h, timeout = post.calls[0]
    assert url == "https://push.example/abc123456" and timeout == 10
    assert h["TTL"] == "86400" and h["Urgency"] == "high" and len(h["Topic"]) <= 32
    assert h["Content-Encoding"] == "aes128gcm"
    payload = json.loads(core.decrypt(body, env.priv, env.auth))
    assert payload["v"] == 1 and payload["type"] == "approval" and payload["body"] == "run it"
    assert payload["approval_id"] == "ap1" and payload["session_id"] == "s1" and len(body) < 4096
    assert env.store.load()["state"]["last_push_at"]


def test_urgency_and_ttl_per_type(env):
    post = FakePost()
    n = notifier(env, post)
    n.notify("scheduled", profile="bot1", title="t", body="b")
    n.notify("task", profile="bot1", title="t", body="b")
    n.drain()
    got = sorted((c[2]["Urgency"], c[2]["TTL"]) for c in post.calls)
    assert got == [("low", "21600"), ("normal", "21600")]


@pytest.mark.parametrize("code", [404, 410])
def test_gone_subscription_dropped(env, code):
    post = FakePost(code)
    n = notifier(env, post)
    n.notify("task", profile="bot1", title="t", body="b")
    n.drain()
    assert env.store.devices() == {}


def test_other_errors_keep_subscription_and_never_raise(env):
    n = notifier(env, FakePost(500))
    n.notify("task", profile="bot1", title="t", body="b")
    n.drain()
    assert "dev1" in env.store.devices()

    def boom(*a, **k):
        raise OSError("net down")
    n2 = notifier(env, boom)
    assert n2.notify("task", profile="bot1", title="t", body="b")
    n2.drain()
    assert "dev1" in env.store.devices()


def test_notify_does_not_block_on_slow_post(env):
    import threading
    import time
    gate = threading.Event()

    def slow(*a, **k):
        gate.wait(3)
        return 201
    n = notifier(env, slow)
    t0 = time.time()
    n.notify("task", profile="bot1", title="t", body="b")
    assert time.time() - t0 < 0.5
    gate.set()
    n.drain()


# ---- dedupe / collapse
def test_same_id_sent_once(env):
    post = FakePost()
    n = notifier(env, post)
    assert n.notify("task", profile="bot1", title="t", body="b", id="same")
    assert not n.notify("task", profile="bot1", title="t", body="b", id="same")
    n.drain()
    assert len(post.calls) == 1


def test_message_burst_collapses_and_flushes_latest(env):
    post, sched, t = FakePost(), [], [100.0]
    n = notifier(env, post, clock=lambda: t[0], scheduled=sched)
    assert n.notify("message", profile="bot1", session_id="s", title="t", body="first")
    t[0] = 105
    assert not n.notify("message", profile="bot1", session_id="s", title="t", body="second")
    t[0] = 110
    assert not n.notify("message", profile="bot1", session_id="s", title="t", body="third")
    assert len(sched) == 1 and sched[0][0] == 15.0
    # different session is independent
    assert n.notify("message", profile="bot1", session_id="other", title="t", body="x")
    n.drain()
    assert len(post.calls) == 2
    t[0] = 120
    sched[0][1]()
    n.drain()
    bodies = [json.loads(core.decrypt(c[1], env.priv, env.auth))["body"] for c in post.calls]
    assert bodies.count("third") == 1 and "second" not in bodies and len(post.calls) == 3
    # after the window a new message sends immediately
    t[0] = 150
    assert n.notify("message", profile="bot1", session_id="s", title="t", body="later")


def test_non_message_types_not_collapsed(env):
    post = FakePost()
    n = notifier(env, post)
    for i in range(3):
        assert n.notify("task", profile="bot1", session_id="s", title="t", body="b")
    n.drain()
    assert len(post.calls) == 3


# ---- hooks
def test_hooks(env, monkeypatch):
    import importlib
    plugin = importlib.import_module("__init__") if False else None
    import importlib.util
    from pathlib import Path
    spec = importlib.util.spec_from_file_location(
        "hermes_push_plugin", Path(core.__file__).parent / "__init__.py",
        submodule_search_locations=[str(Path(core.__file__).parent)])
    plugin = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plugin)
    post = FakePost()
    nt = notifier(env, post)
    monkeypatch.setattr(plugin.core, "get_notifier", lambda: nt)

    registered = {}
    plugin.register(SimpleNamespace(register_hook=lambda n, f: registered.__setitem__(n, f)))
    assert set(registered) == {"pre_approval_request", "kanban_task_completed", "kanban_task_blocked", "post_llm_call"}
    assert env.store.load()["state"]["hooks_registered_at"]

    registered["pre_approval_request"](command="rm -rf x", description="delete", pattern_key="k", session_key="sk",
                                       surface="gateway")
    registered["pre_approval_request"](command="rm -rf x", description="delete", pattern_key="k", session_key="sk",
                                       surface="gateway", coalesced=True)
    registered["post_llm_call"](session_id="s1", turn_id="t1", assistant_response="  ", platform="telegram")
    registered["post_llm_call"](session_id="s1", turn_id="t1", assistant_response="Hello **there**", platform="telegram")
    registered["post_llm_call"](session_id="s2", turn_id="t9", assistant_response="Report ready", platform="cron")
    registered["kanban_task_blocked"](task_id="T1", reason="need input", profile_name="bot1")
    registered["kanban_task_completed"](task_id="T2", summary="done", profile_name="bot1")
    nt.drain()
    got = [json.loads(core.decrypt(c[1], env.priv, env.auth)) for c in post.calls]
    types = sorted(p["type"] for p in got)
    assert types == ["approval", "message", "scheduled", "task", "task"]
    msg = next(p for p in got if p["type"] == "message")
    assert msg["body"] == "Hello there" and msg["profile"] == "bot1"
    assert next(p for p in got if p["type"] == "approval")["approval_id"]


# ---- dashboard routes
def test_routes(env):
    pytest.importorskip("fastapi")
    import importlib.util
    from pathlib import Path
    from fastapi import HTTPException
    path = Path(core.__file__).parent / "dashboard" / "plugin_api.py"
    spec = importlib.util.spec_from_file_location("hp_api", path)
    api = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(api)
    _, p, a = make_receiver()
    api.register(api.RegisterBody(device_id="d9", endpoint="https://x.example/u/1", p256dh=p, auth=a,
                                  prefs={"types": {"task": False}, "bots": {"bot1": "important"}}))
    rec = core.Store().devices()["d9"]
    assert rec["prefs"]["types"]["task"] is False and rec["prefs"]["bots"] == {"bot1": "important"}
    with pytest.raises(HTTPException):
        api.register(api.RegisterBody(device_id="d9", endpoint="javascript:1", p256dh=p, auth=a))
    st = api.status()
    assert st["devices"] == 2 and st["ok"]
    post = FakePost(201)
    core.http_post, orig = post, core.http_post
    try:
        assert api.test(api.DeviceBody(device_id="d9")) == {"ok": True, "status": 201}
    finally:
        core.http_post = orig
    with pytest.raises(HTTPException):
        api.test(api.DeviceBody(device_id="nope"))
    api.unregister(api.DeviceBody(device_id="d9"))
    assert "d9" not in core.Store().devices()
